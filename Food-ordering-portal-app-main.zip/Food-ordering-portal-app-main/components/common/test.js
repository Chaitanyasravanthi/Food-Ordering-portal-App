const test=(props)=>{
    return(
        <h1>Hello</h1>
    );
}

export default test;